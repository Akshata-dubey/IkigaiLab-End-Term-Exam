import './index.css'
import Todos from './components/Todos';

function App() {
  return (
    <div className='text-white py-4'>
      <Todos/>
    </div>
  );
}
export default App;
